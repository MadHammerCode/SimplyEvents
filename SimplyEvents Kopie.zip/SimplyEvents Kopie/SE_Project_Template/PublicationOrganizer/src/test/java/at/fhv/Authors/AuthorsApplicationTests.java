package at.fhv.Authors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
